﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TestDLLCSharp
{
    /**
      *	@enum
      *	Enum representing all type of message that can be pass through the DLL
      */
    public enum TypeData
    {
        /** Info Message*/
        INFO_MESSAGE,
        /** Respond to a Command*/
        DATA_MESSAGE,
        /** A new usb or dongle device has been connected*/
        NEW_DEVICE,
        /** An usb or dongle has been unplug */
        REMOVE_DEVICE,
        /** A bluetooth instrument was found by the scan */
        FOUND_INSTRUMENT,
        /** Conenction step */
        INSTR_CONNECTION_STEP,
        /** Connection to a BT instrument has start */
        CONNECT_START,
        /** A bluetooth instrument was connected successfully */
        CONNECT_SUCCESS,
        /** A bluetooth instrument has failed his connection */
        CONNECT_FAIL,
        /** A bluetooth instrument has been disconnected randomly */
        DISCONNECT_EVENT,
        /** A bluetooth instrument has been disconnected by the user */
        DESIRED_DISCONNECT_EVENT,
        /** A bluetooth scan has start on the dongle */
        SCAN_START,
        /** A bluetooth scan has stop on the dongle */
        SCAN_STOP,
        /** The DLL init has finished */
        END_INIT,
        /** Log message for debug */
        LOG_MESSAGE,
        /** Send an error when a connection fails because the dongle return an error */
        ERROR_DURING_BT_CONNECTION,
        /** An error has occured during the called function */
        ERROR_T,
        DATA_MESSAGE_FROM_BUTTON,
        ERROR_STOP_SCAN,
        ERROR_START_SCAN
    };

    /**
     *	@enum
     *	Enum who give all type of devices that we can connect
     */
    public enum TypeDevice
    {
        /** An usb device with an FTDI chip */
        USB_DEVICE,
        /** A dongle device from Bluegiga */
        DONGLE_DEVICE,
        /** A RS232 Device without FTDI */
        RS232_DEVICE,
        /** A MBRS Device */
        MBRS_DEVICE,
        /** Card Bluetooth */
        BLUETOOTH_CARD,
        /** Laird Bluetooth */
        LAIRD_BLUETOOTH,
        ROTARY_TABLE_RPI
    };

    /**
    *	@enum
    *	Enum to determine the type behind a BT connection
*/
    public enum TypeDeviceBluetooth
    {
        /* Can't determine the type of the instrument */
        TYPE_INSTR_NONE,
        /* It's a real BT instrument supported by the DLL */
        TYPE_INSTRUMENT,
        /* The instrument is a BT pedal */
        TYPE_PEDAL
    };

    /**
     *	@enum
     *	Enum who give all decimal separator that we can use
     */
    public enum TypeDecimalSeparator
    {
        /** All numerical data will use a point */
        DECIMAL_POINT,
        /** All numerical data will use a comma */
        DECIMAL_COMMA,
        /** All numerical data will use the decimal separator that the OS use */
        DEFINED_BY_OS
    };

    /**
     *	@enum
     *	Enum for all the scan that we can start
     */
    public enum TypeScan
    {
        /** A scan only for one mac address */
        SCAN_BY_ADDRESS,
        /** A scan during a defined number of time */
        SCAN_DURING_TIME,
        /** A scan who run all the time */
        SCAN_DURING_ALL_TIME
    };

    /**
     *	@enum
     *	Enum representing the connecting state of a device 
     */
    public enum ConnectionState
    {
        /** No state */
        CONNECTION_STATE_NONE,
        /** Instrument was not connect during the given time */
        CONNECTION_TIMEOUT,
        /** Instrument begin a connection */
        DEVICE_CONNECTING,
        /** Instrument has finished connecting and is connected */
        DEVICE_CONNECTED,
        /** Instrument was disconnected and try to reconnect */
        DEVICE_RECONNECTING,
        /** Instrument was disconnected by the user */
        DESIRED_DISCONNECTION,
        /** Instrument was disconnected randomly */
        NON_DESIRED_DISCONNECTION,
        /** Instrument was disconnected during his connection */
        DISCONNECTION_DURING_CONNECTION,
        /** Instrument is disconnected */
        DEVICE_DISCONNECTED
    };

    /**
     *	@enum
     *	Enum representing all type of instrument that we can connect
     */
    public enum TypeInstrument
    {
        /** Sylvac instrument */
        SYLVAC_INSTR,
        /** IBR instrument */
        IBRBLE_INSTR,
        /** Metrology instrument */
        MTY_INSTR,
        /** Marposs profil */
        MP_INSTR,
        /** GE Profil */
        GE_INSTR,
        /** Unknown name */
        UNKNOWN_INSTR
    };

    public enum MethodEncryption
    {
        UNKNOWN,
        ALREADY_PAIRED,
        PAIRED,
        NON_PAIRED
    };

    /**
     *	@enum
     *	Enum for possible BaudRate 
     */
    public enum ParamBaudRate
    {
        PARAM_110 = 110,
        PARAM_300 = 300,
        PARAM_600 = 600,
        PARAM_1200 = 1200,
        PARAM_2400 = 2400,
        PARAM_4800 = 4800,
        PARAM_9600 = 9600,
        PARAM_14400 = 14400,
        PARAM_19200 = 19200,
        PARAM_28800 = 28800,
        PARAM_38400 = 38400,
        PARAM_56000 = 56000,
        PARAM_57600 = 57600,
        PARAM_115200 = 115200,
        PARAM_128000 = 128000,
        PARAM_153600 = 153600,
        PARAM_230400 = 230400,
        PARAM_256000 = 256000,
        PARAM_460800 = 460800,
        PARAM_921600 = 921600
    };

    /**
     *	@enum
     *	Enum for possible parity
     */
    public enum ParamParity
    {
        NO_PARITY = 0,
        ODD_PARITY = 1,
        EVEN_PARITY = 2,
        MARK_PARITY = 3,
        SPACE_PARITY = 4
    };

    /**
     *	@enum
     *	Enum for possible stop bits
     */
    public enum ParamStopBit
    {
        ONE_STOP_BIT = 0,
        ONE_HALF_STOP_BIT = 1,
        TWO_STOP_BIT = 2
    };

    /**
     *	@enum
     *	Enum for possible byte size
     */
    public enum ParamByteSize
    {
        BITS_8 = 8,
        BITS_7 = 7,
        BITS_6 = 6,
        BITS_5 = 5
    };
}
