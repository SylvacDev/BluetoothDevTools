﻿namespace TestDLLCSharp
{
    partial class FrmMain
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
			this.btnRefresh = new System.Windows.Forms.Button();
			this.btnScan = new System.Windows.Forms.Button();
			this.btnConnect = new System.Windows.Forms.Button();
			this.cmbDevice = new System.Windows.Forms.ComboBox();
			this.cmbFounded = new System.Windows.Forms.ComboBox();
			this.cmbConnectedInstr = new System.Windows.Forms.ComboBox();
			this.label1 = new System.Windows.Forms.Label();
			this.lblConnectedInstr = new System.Windows.Forms.Label();
			this.lblFoundInstr = new System.Windows.Forms.Label();
			this.btnDisconnect = new System.Windows.Forms.Button();
			this.btnQuit = new System.Windows.Forms.Button();
			this.txtInfos = new System.Windows.Forms.TextBox();
			this.txtCmd = new System.Windows.Forms.TextBox();
			this.btnSend = new System.Windows.Forms.Button();
			this.btnSetParam = new System.Windows.Forms.Button();
			this.btnStop = new System.Windows.Forms.Button();
			this.btnSendAll = new System.Windows.Forms.Button();
			this.btnReset = new System.Windows.Forms.Button();
			this.btnListing = new System.Windows.Forms.Button();
			this.btnChangeParam = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// btnRefresh
			// 
			this.btnRefresh.Location = new System.Drawing.Point(255, 334);
			this.btnRefresh.Name = "btnRefresh";
			this.btnRefresh.Size = new System.Drawing.Size(75, 23);
			this.btnRefresh.TabIndex = 0;
			this.btnRefresh.Text = "Refresh";
			this.btnRefresh.UseVisualStyleBackColor = true;
			this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
			// 
			// btnScan
			// 
			this.btnScan.Location = new System.Drawing.Point(32, 288);
			this.btnScan.Name = "btnScan";
			this.btnScan.Size = new System.Drawing.Size(75, 23);
			this.btnScan.TabIndex = 1;
			this.btnScan.Text = "Start Scan";
			this.btnScan.UseVisualStyleBackColor = true;
			this.btnScan.Click += new System.EventHandler(this.btnScan_Click);
			// 
			// btnConnect
			// 
			this.btnConnect.Location = new System.Drawing.Point(246, 288);
			this.btnConnect.Name = "btnConnect";
			this.btnConnect.Size = new System.Drawing.Size(75, 23);
			this.btnConnect.TabIndex = 2;
			this.btnConnect.Text = "Connect";
			this.btnConnect.UseVisualStyleBackColor = true;
			this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
			// 
			// cmbDevice
			// 
			this.cmbDevice.FormattingEnabled = true;
			this.cmbDevice.Location = new System.Drawing.Point(32, 43);
			this.cmbDevice.Name = "cmbDevice";
			this.cmbDevice.Size = new System.Drawing.Size(168, 21);
			this.cmbDevice.TabIndex = 3;
			this.cmbDevice.SelectedIndexChanged += new System.EventHandler(this.cmbDevice_SelectedIndexChanged);
			// 
			// cmbFounded
			// 
			this.cmbFounded.FormattingEnabled = true;
			this.cmbFounded.Location = new System.Drawing.Point(221, 52);
			this.cmbFounded.Name = "cmbFounded";
			this.cmbFounded.Size = new System.Drawing.Size(121, 21);
			this.cmbFounded.TabIndex = 4;
			this.cmbFounded.SelectedIndexChanged += new System.EventHandler(this.cmbFounded_SelectedIndexChanged);
			// 
			// cmbConnectedInstr
			// 
			this.cmbConnectedInstr.FormattingEnabled = true;
			this.cmbConnectedInstr.Location = new System.Drawing.Point(366, 52);
			this.cmbConnectedInstr.Name = "cmbConnectedInstr";
			this.cmbConnectedInstr.Size = new System.Drawing.Size(121, 21);
			this.cmbConnectedInstr.TabIndex = 5;
			this.cmbConnectedInstr.SelectedIndexChanged += new System.EventHandler(this.cmbConnectedInstr_SelectedIndexChanged);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(29, 27);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(63, 13);
			this.label1.TabIndex = 6;
			this.label1.Text = "List devices";
			// 
			// lblConnectedInstr
			// 
			this.lblConnectedInstr.AutoSize = true;
			this.lblConnectedInstr.Location = new System.Drawing.Point(363, 27);
			this.lblConnectedInstr.Name = "lblConnectedInstr";
			this.lblConnectedInstr.Size = new System.Drawing.Size(136, 13);
			this.lblConnectedInstr.TabIndex = 7;
			this.lblConnectedInstr.Text = "List connected instruments ";
			// 
			// lblFoundInstr
			// 
			this.lblFoundInstr.AutoSize = true;
			this.lblFoundInstr.Location = new System.Drawing.Point(218, 27);
			this.lblFoundInstr.Name = "lblFoundInstr";
			this.lblFoundInstr.Size = new System.Drawing.Size(109, 13);
			this.lblFoundInstr.TabIndex = 8;
			this.lblFoundInstr.Text = "List found instruments";
			// 
			// btnDisconnect
			// 
			this.btnDisconnect.Location = new System.Drawing.Point(327, 288);
			this.btnDisconnect.Name = "btnDisconnect";
			this.btnDisconnect.Size = new System.Drawing.Size(75, 23);
			this.btnDisconnect.TabIndex = 9;
			this.btnDisconnect.Text = "Disconnect";
			this.btnDisconnect.UseVisualStyleBackColor = true;
			this.btnDisconnect.Click += new System.EventHandler(this.btnDisconnect_Click);
			// 
			// btnQuit
			// 
			this.btnQuit.Location = new System.Drawing.Point(417, 334);
			this.btnQuit.Name = "btnQuit";
			this.btnQuit.Size = new System.Drawing.Size(75, 23);
			this.btnQuit.TabIndex = 10;
			this.btnQuit.Text = "Quit";
			this.btnQuit.UseVisualStyleBackColor = true;
			this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
			// 
			// txtInfos
			// 
			this.txtInfos.Location = new System.Drawing.Point(32, 99);
			this.txtInfos.Multiline = true;
			this.txtInfos.Name = "txtInfos";
			this.txtInfos.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.txtInfos.Size = new System.Drawing.Size(434, 125);
			this.txtInfos.TabIndex = 11;
			// 
			// txtCmd
			// 
			this.txtCmd.Location = new System.Drawing.Point(32, 245);
			this.txtCmd.Name = "txtCmd";
			this.txtCmd.Size = new System.Drawing.Size(434, 20);
			this.txtCmd.TabIndex = 12;
			this.txtCmd.TextChanged += new System.EventHandler(this.txtCmd_TextChanged);
			// 
			// btnSend
			// 
			this.btnSend.Location = new System.Drawing.Point(93, 334);
			this.btnSend.Name = "btnSend";
			this.btnSend.Size = new System.Drawing.Size(75, 23);
			this.btnSend.TabIndex = 13;
			this.btnSend.Text = "Send Cmd";
			this.btnSend.UseVisualStyleBackColor = true;
			this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
			// 
			// btnSetParam
			// 
			this.btnSetParam.Location = new System.Drawing.Point(113, 288);
			this.btnSetParam.Name = "btnSetParam";
			this.btnSetParam.Size = new System.Drawing.Size(120, 23);
			this.btnSetParam.TabIndex = 14;
			this.btnSetParam.Text = "Set Scan Parameter";
			this.btnSetParam.UseVisualStyleBackColor = true;
			this.btnSetParam.Click += new System.EventHandler(this.btnSetParam_Click);
			// 
			// btnStop
			// 
			this.btnStop.Location = new System.Drawing.Point(12, 334);
			this.btnStop.Name = "btnStop";
			this.btnStop.Size = new System.Drawing.Size(75, 23);
			this.btnStop.TabIndex = 15;
			this.btnStop.Text = "Stop Scan";
			this.btnStop.UseVisualStyleBackColor = true;
			this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
			// 
			// btnSendAll
			// 
			this.btnSendAll.Location = new System.Drawing.Point(174, 334);
			this.btnSendAll.Name = "btnSendAll";
			this.btnSendAll.Size = new System.Drawing.Size(75, 23);
			this.btnSendAll.TabIndex = 16;
			this.btnSendAll.Text = "Send to All";
			this.btnSendAll.UseVisualStyleBackColor = true;
			this.btnSendAll.Click += new System.EventHandler(this.btnSendAll_Click);
			// 
			// btnReset
			// 
			this.btnReset.Location = new System.Drawing.Point(409, 288);
			this.btnReset.Name = "btnReset";
			this.btnReset.Size = new System.Drawing.Size(75, 23);
			this.btnReset.TabIndex = 17;
			this.btnReset.Text = "Reset dongle";
			this.btnReset.UseVisualStyleBackColor = true;
			this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
			// 
			// btnListing
			// 
			this.btnListing.Location = new System.Drawing.Point(336, 334);
			this.btnListing.Name = "btnListing";
			this.btnListing.Size = new System.Drawing.Size(75, 23);
			this.btnListing.TabIndex = 18;
			this.btnListing.Text = "Listing";
			this.btnListing.UseVisualStyleBackColor = true;
			this.btnListing.Click += new System.EventHandler(this.btnListing_Click);
			// 
			// btnChangeParam
			// 
			this.btnChangeParam.Location = new System.Drawing.Point(32, 70);
			this.btnChangeParam.Name = "btnChangeParam";
			this.btnChangeParam.Size = new System.Drawing.Size(168, 23);
			this.btnChangeParam.TabIndex = 19;
			this.btnChangeParam.Text = "Change Comm Params";
			this.btnChangeParam.UseVisualStyleBackColor = true;
			this.btnChangeParam.Click += new System.EventHandler(this.btnChangeParam_Click);
			// 
			// FrmMain
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(496, 369);
			this.Controls.Add(this.btnChangeParam);
			this.Controls.Add(this.btnListing);
			this.Controls.Add(this.btnReset);
			this.Controls.Add(this.btnSendAll);
			this.Controls.Add(this.btnStop);
			this.Controls.Add(this.btnSetParam);
			this.Controls.Add(this.btnSend);
			this.Controls.Add(this.txtCmd);
			this.Controls.Add(this.txtInfos);
			this.Controls.Add(this.btnQuit);
			this.Controls.Add(this.btnDisconnect);
			this.Controls.Add(this.lblFoundInstr);
			this.Controls.Add(this.lblConnectedInstr);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.cmbConnectedInstr);
			this.Controls.Add(this.cmbFounded);
			this.Controls.Add(this.cmbDevice);
			this.Controls.Add(this.btnConnect);
			this.Controls.Add(this.btnScan);
			this.Controls.Add(this.btnRefresh);
			this.Name = "FrmMain";
			this.Text = "Test DLL";
			this.Load += new System.EventHandler(this.FrmMain_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnScan;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.ComboBox cmbDevice;
        private System.Windows.Forms.ComboBox cmbFounded;
        private System.Windows.Forms.ComboBox cmbConnectedInstr;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblConnectedInstr;
        private System.Windows.Forms.Label lblFoundInstr;
        private System.Windows.Forms.Button btnDisconnect;
        private System.Windows.Forms.Button btnQuit;
        private System.Windows.Forms.TextBox txtInfos;
        private System.Windows.Forms.TextBox txtCmd;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.Button btnSetParam;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Button btnSendAll;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnListing;
        private System.Windows.Forms.Button btnChangeParam;
    }
}

