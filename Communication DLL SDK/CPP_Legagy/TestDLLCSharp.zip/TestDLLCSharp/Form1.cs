﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace TestDLLCSharp
{

    /**
 *  Struct who define a device (USB or Dongle)
 *
 *	@param deviceNumber	 The number of the device
 *	@param port			 The handle where the device is connected
 *	@param type			 The type of device
 */
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    public struct DeviceInfo
    {

        public uint deviceNumber;
        public TypeDevice type;

#if WindowsCE
        public IntPtr uniqueID;
#else
        [MarshalAs(UnmanagedType.BStr)]
        public string uniqueID;
#endif

#if WindowsCE
        public IntPtr description;
#else
        [MarshalAs(UnmanagedType.BStr)]
        public string description;
#endif
    };

    /**
    *	Struct who define a bluetooth instrument
    *
    *	@param	instrNumber		 The number of the instrument
    *	@param  bond			 The bond value of the instrument (if 0xFF => no bond)
    *	@param	dongleMacAddress The dongle mac address where this instrument is attached
    *	@param	macAddress		 The mac address of the instrument
    *	@param  name			 The advertisement name of the device
    *	@param	state			 The connection state of the instrument
    *   @param  typeDeviceBt	 The type of the Bluetooth device (no use for the moment)
    *	@param	type			 The type of the instrument (Sylvac, MTY or IBRBLE)
    *	@param  writeHandle		 The handle where to write on the bluetooth characteristic (you don't have to touch this)
    *	@param	packet			 The Advertisement packet receive from the bluetooth device before the connection
    */
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    public struct BTInstrumentAdv
    {
        public uint instrNumber;
        public ushort bond;
        [MarshalAs(UnmanagedType.BStr)]
        public string dongleAddress;
        [MarshalAs(UnmanagedType.BStr)]
        public string macAddress;
        [MarshalAs(UnmanagedType.BStr)]
        public string name;
        public ConnectionState state;
        public TypeDeviceBluetooth typeDeviceBt;
        public ushort writeHandle;
        public sbyte rssi;
        [MarshalAs(UnmanagedType.BStr)]
        public string nameAdv;
        [MarshalAs(UnmanagedType.BStr)]
        public string saleNumber;
        [MarshalAs(UnmanagedType.BStr)]
        public string advValue;
        public MethodEncryption methodEncrypt;
    };

    /// <summary>
    /// Delegate type of the callback function that is called from the SyComLib DLL.
    /// </summary>
    /// <param name="message">Message content</param>
    /// <param name="deviceId">Unique ID used by the SyComLib DLL to identify a device.</param>
    /// <param name="messageType">Type of the event that caused the SyComLib DLL to send the message.</param>
    [UnmanagedFunctionPointer(CallingConvention.StdCall)]
    public delegate void DataRecover([In, MarshalAs(UnmanagedType.BStr)]string message, [In, MarshalAs(UnmanagedType.BStr)]string deviceId, TypeData messageType, Int32 token);

    delegate void updateInfo(string message);
    delegate void refreshDelegate();
    delegate void updateListDevice();


    public partial class FrmMain : Form
    {

        [DllImport("SylvacInstrumentsCommunicationdll.dll", CallingConvention = CallingConvention.Winapi)]
        [return: MarshalAs(UnmanagedType.BStr)]
        public static extern string SY_getDLLVersion();

        [DllImport("SylvacInstrumentsCommunicationdll.dll", CallingConvention = CallingConvention.Winapi)]
        [return: MarshalAs(UnmanagedType.BStr)]
        public static extern string SY_toString(uint deviceNumber);

        [DllImport("SylvacInstrumentsCommunicationdll.dll", CallingConvention = CallingConvention.Winapi)]
        private static extern uint SY_getNumberDeviceConnected();

        [DllImport("SylvacInstrumentsCommunicationdll.dll", CallingConvention = CallingConvention.Winapi)]
        public static extern uint SY_getNumberInstrFound(uint dongleNumber);

        [DllImport("SylvacInstrumentsCommunicationdll.dll", CallingConvention = CallingConvention.Winapi)]
        public static extern uint SY_getNumberInstrConnectedByDongle(uint dongleNumber);

        [DllImport("SylvacInstrumentsCommunicationdll.dll", CallingConvention = CallingConvention.Winapi)]
        public static extern void SY_runAScan(TypeScan typeScan, [MarshalAs(UnmanagedType.BStr)]string arg, uint deviceNumber);

        [DllImport("SylvacInstrumentsCommunicationdll.dll", CallingConvention = CallingConvention.Winapi)]
        public static extern void SY_runAScanForAddress([MarshalAs(UnmanagedType.BStr)]string address, int time, uint dongleNumber);

        [DllImport("SylvacInstrumentsCommunicationdll.dll", CallingConvention = CallingConvention.Winapi)]
        public static extern void SY_runAScanForAddressForReconnection([MarshalAs(UnmanagedType.BStr)]string address, int time, uint dongleNumber, uint writeHandle);

        [DllImport("SylvacInstrumentsCommunicationdll.dll", CallingConvention = CallingConvention.Winapi)]
        public static extern void SY_runAScanForTime(int time, uint dongleNumber);

        [DllImport("SylvacInstrumentsCommunicationdll.dll", CallingConvention = CallingConvention.Winapi)]
        private static extern void SY_getDeviceInfo(uint indexNumber, [MarshalAs(UnmanagedType.Struct)] out DeviceInfo device);

        [DllImport("SylvacInstrumentsCommunicationdll.dll", CallingConvention = CallingConvention.Winapi)]
        public static extern void SY_quit();

        [DllImport("SylvacInstrumentsCommunicationdll.dll", CallingConvention = CallingConvention.Winapi)]
        private static extern void SY_sendCmd([In, MarshalAs(UnmanagedType.BStr)]string cmd, [In, MarshalAs(UnmanagedType.Struct)] ref DeviceInfo device, int instrNumber = -1);

        [DllImport("SylvacInstrumentsCommunicationdll.dll", CallingConvention = CallingConvention.Winapi)]
        private static extern void SY_sendCmdWithDefineEndTrame([In, MarshalAs(UnmanagedType.BStr)]string cmd, [In, MarshalAs(UnmanagedType.Struct)] ref DeviceInfo device, [In, MarshalAs(UnmanagedType.BStr)]string regexEndOfTrame, int instrNumber = -1);

        [DllImport("SylvacInstrumentsCommunicationdll.dll", CallingConvention = CallingConvention.Winapi)]
        public static extern void SY_connectInstr(uint dongleNumber, uint instrNumber, uint writeHandle = 0);

        [DllImport("SylvacInstrumentsCommunicationdll.dll", CallingConvention = CallingConvention.Winapi)]
        public static extern void SY_disconnect([MarshalAs(UnmanagedType.Struct)]ref DeviceInfo device);

        [DllImport("SylvacInstrumentsCommunicationdll.dll", CallingConvention = CallingConvention.Winapi)]
        public static extern void SY_disconnectInstr(uint dongleNumber, uint instrNumber, [MarshalAs(UnmanagedType.Bool)] bool withRST);

        [DllImport("SylvacInstrumentsCommunicationdll.dll", CallingConvention = CallingConvention.Winapi)]
        public static extern void SY_reconnectIfResetPressed(bool state);

        [DllImport("SylvacInstrumentsCommunicationdll.dll", CallingConvention = CallingConvention.Winapi)]
        public static extern bool SY_getBTInstrAdvFromDongle(uint dongleNumber, uint indexInstr, [MarshalAs(UnmanagedType.Struct)]out BTInstrumentAdv instr);

        [DllImport("SylvacInstrumentsCommunicationdll.dll", CallingConvention = CallingConvention.Winapi)]
        public static extern bool SY_getFoundBTInstrAdv(uint dongleNumber, uint indexInstr, [MarshalAs(UnmanagedType.Struct)]out BTInstrumentAdv instr);

        [DllImport("SylvacInstrumentsCommunicationdll.dll", CallingConvention = CallingConvention.Winapi)]
        public static extern bool SY_changeParamCommunication([In, MarshalAs(UnmanagedType.Struct)] ref DeviceInfo device, ParamBaudRate baudRate, ParamByteSize byteSize, ParamParity parity, ParamStopBit stopBits);

        [DllImport("SylvacInstrumentsCommunicationdll.dll", CallingConvention = CallingConvention.Winapi)]
        public static extern void SY_resetDongle(uint dongleNumber);

        [DllImport("SylvacInstrumentsCommunicationdll.dll", CallingConvention = CallingConvention.Winapi)]
        public static extern void SY_stopScan(uint dongleNumber);

        //Return a list under the form mac1;mac2;mac3;... to get all the mac address already pair to the device
        [DllImport("SylvacInstrumentsCommunicationdll.dll", CallingConvention = CallingConvention.Winapi)]
        [return: MarshalAs(UnmanagedType.BStr)]
        public static extern string SY_getPairedDeviceFromDongle(uint dongleNumber);

        [DllImport("SylvacInstrumentsCommunicationdll.dll", CallingConvention = CallingConvention.Winapi)]
        public static extern void SY_clearFoundInstrList(uint dongleNumber);

        [DllImport("SylvacInstrumentsCommunicationdll.dll", CallingConvention = CallingConvention.Winapi)]
        public static extern void SY_deleteBond(uint dongleNumber, ushort bond);

        [DllImport("SylvacInstrumentsCommunicationdll.dll", CallingConvention = CallingConvention.Winapi)]
        public static extern bool SY_changeDeviceAdvertisementName([In, MarshalAs(UnmanagedType.BStr)]string newName, uint dongleDeviceNumber, uint instrNumber);

        [DllImport("SylvacInstrumentsCommunicationdll.dll", CallingConvention = CallingConvention.Winapi)]
        public static extern bool SY_eraseBondOnMasterOnly(uint dongleDeviceNumber, [In, MarshalAs(UnmanagedType.BStr)]string strMac);

        //http://stackoverflow.com/questions/13280323/calling-a-dll-function-that-contains-a-function-pointer-from-c-sharp
        [DllImport("SylvacInstrumentsCommunicationdll.dll", CallingConvention = CallingConvention.Winapi)]
        public static extern void SY_init([MarshalAs(UnmanagedType.FunctionPtr)] DataRecover bridge, TypeDecimalSeparator typeDec);

        List<DeviceInfo> listDevice;
        Dictionary<string, List<string>> instrOnDongle;
        InputBox inputScan;
        bool init = false;
        DataRecover delData;

        public FrmMain()
        {
            //MessageBox.Show("Start frmMain Init", "Info", MessageBoxButtons.YesNo);
           // AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(MyHandler);
            InitializeComponent(); 
            listDevice = new List<DeviceInfo>();
            instrOnDongle = new Dictionary<string,List<string>>();
            inputScan = new InputBox();
            cmbConnectedInstr.Visible = false; 
            cmbFounded.Visible = false;
            lblConnectedInstr.Visible = false;
            lblFoundInstr.Visible = false;
            btnConnect.Enabled = false;
            btnSendAll.Enabled = false;
            btnReset.Enabled = false;
            btnDisconnect.Enabled = false;
            btnScan.Enabled = false;
            btnSend.Enabled = false;
            btnChangeParam.Enabled = false;
            txtInfos.ReadOnly = true;

            this.FormClosing += FrmMain_FormClosing; 


          //  try {
                //MessageBox.Show("First DLL Call", "Info", MessageBoxButtons.YesNo);
                this.Text += " " + SY_getDLLVersion();
                //MessageBox.Show("End First DLL Call", "Info", MessageBoxButtons.YesNo);
           /* } catch (Exception e) {0.
                MessageBox.Show("Exception: " + e.Message + Environment.NewLine + e.StackTrace, "Info", MessageBoxButtons.YesNo);
            }*/

        }

      /*  static void MyHandler(object sender, UnhandledExceptionEventArgs args) {

            Exception e = (Exception)args.ExceptionObject;

            MessageBox.Show("Exception Message: " + e.Message, "Error", MessageBoxButtons.OK);

        }*/


        private void FrmMain_Load(object sender, EventArgs e){

            delData = dataRecover;
            //try{
                SY_init(delData, TypeDecimalSeparator.DECIMAL_COMMA);
           /* } catch (Exception ex) {
                MessageBox.Show("Exception: " + ex.Message + Environment.NewLine + ex.StackTrace + Environment.NewLine + ex.InnerException, "Info", MessageBoxButtons.YesNo);
            }*/
            //MessageBox.Show("End Init DLL Call", "Info", MessageBoxButtons.YesNo);

            init = true;
            getConnectedInstr();
        }

        private void FrmMain_FormClosing(object sender, CancelEventArgs e)
        {
            SY_quit();
        }

        private void updateTxtInfos(string mess){
            txtInfos.AppendText(mess + Environment.NewLine);
        }

        private DeviceInfo recoverInstrument(string serial){
            for (int i = 0; i < listDevice.Count; i++) {
                if (serial.Equals(listDevice[i].uniqueID))
                {
                    return listDevice[i];
                }
            }

            return new DeviceInfo();
        }

        private string getDongleMacFromInstr(string mac) {

            foreach (string dongle in instrOnDongle.Keys.ToArray()) {
                List<string> macInstr = instrOnDongle[dongle];

                foreach (string macAddress in macInstr) {
                    if (macAddress.Equals(mac))
                    {
                        return dongle;
                    }
                }
            }
            return "";
        }

        private void refreshBox(){
            Application.DoEvents();
            int index = cmbDevice.SelectedIndex;
            resetCombo();
            cmbDevice.SelectedIndex = -1;
            cmbDevice.SelectedIndex = index;
        }

        private void refreshAndErase()
        {
            refreshBox();
            cmbFounded.Items.Clear();
        }

        /**
         *   Manage all the message coming from the DLL
         *   The TypeData shows which type of message we receive
         */
        private void manageMessage(string message, string id, TypeData type){
            string txtAffichage = "";
            
            lock (this)
            {
                string dongleAdd = id;

                if (!instrOnDongle.ContainsKey(dongleAdd))
                {
                    dongleAdd = getDongleMacFromInstr(id);
                }

                switch (type)
                {
                    case TypeData.INFO_MESSAGE:
                        txtAffichage = "Received info: " + message;
                        break;
                    case TypeData.DATA_MESSAGE_FROM_BUTTON:
                        {
                            DeviceInfo info = recoverInstrument(id);
                            string typeD = "";

                            if (info.uniqueID == null)
                            {
                                typeD += " from " + Enum.GetName(typeof(TypeDevice), TypeDevice.DONGLE_DEVICE) + " (" + dongleAdd + ")";
                            }
                            else
                            {
                                typeD += " from " + Enum.GetName(typeof(TypeDevice), info.type);
                            }

                            txtAffichage = "Received button data " + message.Trim('\r') + typeD + " instrument " + id;
                        }
                        break;
                    case TypeData.DATA_MESSAGE:
                        {
                            DeviceInfo info = recoverInstrument(id);
                            string typeD = "";

                            if (info.uniqueID == null)
                            {
                                info = recoverInstrument(dongleAdd);

                                if(info.uniqueID != null)
                                {
                                    typeD += " from " + Enum.GetName(typeof(TypeDevice), info.type) + " (" + dongleAdd + ")";
                                }
                                else
                                {
                                    typeD += " from " + Enum.GetName(typeof(TypeDevice), TypeDevice.DONGLE_DEVICE) + " (" + dongleAdd + ")";
                                }
                            }
                            else
                            {
                                typeD += " from " + Enum.GetName(typeof(TypeDevice), info.type);
                            }

                            txtAffichage = "Received data " + message.Trim('\r') + typeD + " instrument " + id;
                        }
                        break;
                    case TypeData.CONNECT_SUCCESS:
                        txtAffichage = message;
                        if (cmbDevice.InvokeRequired)
                        {
                            refreshDelegate update = new refreshDelegate(refreshAndErase);
                            this.BeginInvoke(update);
                        }
                        else
                        {
                            refreshAndErase();
                        }

                        break;
                    case TypeData.FOUND_INSTRUMENT:
                        txtAffichage = message;
                        if (cmbDevice.InvokeRequired)
                        {
                            refreshDelegate update = new refreshDelegate(refreshBox);
                            this.BeginInvoke(update);
                        }
                        else
                        {
                            refreshBox();
                        }
                        break;
                    case TypeData.CONNECT_FAIL:
                        txtAffichage = message;
                        break;
                    case TypeData.DISCONNECT_EVENT:
                        txtAffichage = message;
                        break;
                    case TypeData.ERROR_T:
                        txtAffichage = "An error occured => " + message;
                        break;
                    case TypeData.LOG_MESSAGE:
                        Console.WriteLine(message);
                        break;
                    case TypeData.SCAN_START:
                        txtAffichage = message;
                        break;
                    case TypeData.SCAN_STOP:
                        txtAffichage = message;
                        break;
                    case TypeData.REMOVE_DEVICE:
                    case TypeData.NEW_DEVICE:
                        txtAffichage = message;
                        if (init)
                        {
                            if (this.txtInfos.InvokeRequired)
                            {
                                updateListDevice update = new updateListDevice(getConnectedInstr);
                                this.BeginInvoke(update);
                            }
                            else
                            {
                                getConnectedInstr();
                            }
                        }
                        break;
                    default:
                        txtAffichage = message;
                        break;
                }
            }

            if (txtAffichage.Equals("")){
                return;
            }

            txtAffichage = "[" + DateTime.Now.ToString("hh:mm:ss - fff") +"] " + txtAffichage;

            if (this.txtInfos.InvokeRequired){
                updateInfo update = new updateInfo(updateTxtInfos);
                this.Invoke(update, new object[] { txtAffichage });
            }else{
                updateTxtInfos(txtAffichage);
            }
        
        }

        /**
         *  We create the callback function where we will receive the message from the DLL
         */ 
        private void dataRecover(string message, string id, TypeData type, Int32 token)
        {
            Thread workerThread = new Thread(() => manageMessage(message, id, type));
            workerThread.Start();
        }

        /**
         * Get all connected device
         */ 
        private void getConnectedInstr() {

            int index = cmbDevice.SelectedIndex;
            cmbDevice.SelectedIndex = -1;

            listDevice.Clear();
            cmbDevice.Items.Clear();

            //Get the number of connected device
            uint nbDeviceConnected = SY_getNumberDeviceConnected();

            //Iterate on this number
            for (uint i = 0; i < nbDeviceConnected; i++){
                DeviceInfo info = new DeviceInfo();
                //Recove a device
                SY_getDeviceInfo(i, out info);
                //Add it to the combobox
                cmbDevice.Items.Add(info.deviceNumber + ": " + info.description); //Enum.GetName(typeof(TypeDevice), info.type) + " (" + info.uniqueID + ")");
                //Add it to the list
                listDevice.Add(info);

                //if it's a new dongle, we create the list of instrument attached to this dongle
                if (isBleDevice(info.type) && !instrOnDongle.ContainsKey(info.uniqueID))
                {
                    instrOnDongle.Add(info.uniqueID, new List<string>());
                }
            }

            if (cmbDevice.Items.Count <= index && index != -1){
                cmbDevice.SelectedIndex = listDevice.Count - 1;
            }else{
                cmbDevice.SelectedIndex = index;
            }
        }

        private void cmbDevice_SelectedIndexChanged(object sender, EventArgs e){
            if(cmbDevice.SelectedIndex == -1)
                return;

            DeviceInfo info = listDevice[cmbDevice.SelectedIndex];

            cmbConnectedInstr.Visible = isBleDevice(info.type);
            cmbFounded.Visible = cmbConnectedInstr.Visible;
            lblConnectedInstr.Visible = cmbConnectedInstr.Visible;
            lblFoundInstr.Visible = cmbConnectedInstr.Visible;

            if (isBleDevice(info.type))
            {
                refresh(info);
            }

            btnChangeParam.Enabled = cmbDevice.SelectedIndex != -1;
            btnScan.Enabled = isBleDevice(info.type);
            btnStop.Enabled = isBleDevice(info.type);
            btnReset.Enabled = isBleDevice(info.type);
            btnConnect.Enabled = btnScan.Enabled && cmbFounded.SelectedIndex != -1;
            btnDisconnect.Enabled = btnScan.Enabled && cmbDevice.SelectedIndex != -1;
            btnSend.Enabled = (info.type != TypeDevice.DONGLE_DEVICE && info.type != TypeDevice.BLUETOOTH_CARD && info.type != TypeDevice.LAIRD_BLUETOOTH && txtCmd.Text != "") ||
                                (isBleDevice(info.type) && cmbConnectedInstr.SelectedIndex != -1 && txtCmd.Text != "");

        }

        /*
         *  Refresh all combobox with the device found and the connected device
         */ 
        private void refresh(DeviceInfo info) {
            
           // getConnectedInstr();
            try{

                List<string> listMac = instrOnDongle[info.uniqueID];
                listMac.Clear();

                BTInstrumentAdv instr = new BTInstrumentAdv();

                //Update with the found devices
                uint nbInstrFound = SY_getNumberInstrFound(info.deviceNumber);
                cmbFounded.Items.Clear();

                for (uint i = 0; i < nbInstrFound; i++)
                {
                    SY_getFoundBTInstrAdv(info.deviceNumber, i, out instr);
                    cmbFounded.Items.Add(i + ": " + instr.macAddress);
                }

                //Update with the connected device
                uint nbInstrOnDongle = SY_getNumberInstrConnectedByDongle(info.deviceNumber);
                cmbConnectedInstr.Items.Clear();

                for (uint i = 0; i < nbInstrOnDongle; i++)
                {
                    SY_getBTInstrAdvFromDongle(info.deviceNumber, i, out instr);
                    cmbConnectedInstr.Items.Add(instr.instrNumber + ": " + instr.macAddress);
                    listMac.Add(instr.macAddress);
                }

                instrOnDongle[info.uniqueID] = listMac;

                Console.WriteLine("Refresh finished");
            }
            catch (Exception e) {
                Console.WriteLine("Exception: " + e.StackTrace);
            }

        }

        private void resetCombo() {
            cmbConnectedInstr.Items.Clear();
            cmbConnectedInstr.SelectedIndex = -1;
            cmbConnectedInstr.Text = "";

            cmbFounded.Items.Clear();
            cmbFounded.SelectedIndex = -1;
            cmbFounded.Text = "";
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            resetCombo();
            getConnectedInstr();
        }

        private void cmbFounded_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnConnect.Enabled = cmbFounded.SelectedIndex != -1;
        }

        private void cmbConnectedInstr_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnDisconnect.Enabled = cmbConnectedInstr.SelectedIndex != -1;
            btnSend.Enabled = cmbConnectedInstr.SelectedIndex != -1 && txtCmd.Text != "";
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            SY_quit();
            Application.Exit();
        }

        private void btnScan_Click(object sender, EventArgs e)
        {
            startScan();
        }

        public void startScan() {
            try
            {
                //Get the dongle with the index of the combobox
                DeviceInfo info = listDevice[cmbDevice.SelectedIndex];
                TypeScan type = inputScan.getType();
                string arg = inputScan.getArg();
                SY_runAScanForTime(Convert.ToInt32(arg), info.deviceNumber);
            }
            catch (Exception e) {
                Console.WriteLine(e.StackTrace);
            }
        }

        private void txtCmd_TextChanged(object sender, EventArgs e)
        {

            if (cmbDevice.SelectedIndex != -1)
            {
                DeviceInfo info = listDevice[cmbDevice.SelectedIndex];

                btnSend.Enabled = (info.type != TypeDevice.DONGLE_DEVICE && info.type != TypeDevice.BLUETOOTH_CARD && info.type != TypeDevice.LAIRD_BLUETOOTH && cmbDevice.SelectedIndex != -1 && txtCmd.Text != "") ||
                                    (isBleDevice(info.type) && cmbDevice.SelectedIndex != -1 && cmbConnectedInstr.SelectedIndex != -1 && txtCmd.Text != "");
            }

            btnSendAll.Enabled = txtCmd.Text != "";
        }

        private BTInstrumentAdv getInstrFromDongle(uint dongleNumber, uint indexInstr) {
            BTInstrumentAdv bt = new BTInstrumentAdv();

            SY_getBTInstrAdvFromDongle(dongleNumber, indexInstr, out bt);

            return bt;
        }

        private BTInstrumentAdv getFoundBTInstr(uint dongleNumber, uint indexInstr)
        {
            BTInstrumentAdv bt = new BTInstrumentAdv();

            SY_getFoundBTInstrAdv(dongleNumber, indexInstr, out bt);

            return bt;
        }

        private bool isBleDevice(TypeDevice type)
        {
            return type == TypeDevice.BLUETOOTH_CARD || type == TypeDevice.DONGLE_DEVICE || type == TypeDevice.LAIRD_BLUETOOTH;
        }

        //Send cmd
        private void btnSend_Click(object sender, EventArgs e)
        {

            if(cmbDevice.SelectedIndex < 0)
                return;

            DeviceInfo info = listDevice[cmbDevice.SelectedIndex];

            if (isBleDevice(info.type) && cmbConnectedInstr.SelectedIndex == -1)
                return;

            string cmd = txtCmd.Text;

            if (isBleDevice(info.type))
            {
                BTInstrumentAdv instr = getInstrFromDongle(info.deviceNumber, (uint)cmbConnectedInstr.SelectedIndex);
                SY_sendCmd(cmd, ref info, (int)instr.instrNumber);

                displaySendetCommand(cmd, instr.macAddress);
            }
            else
            {
                string end = '\r'.ToString();

                if (cmd.Contains("@ID"))
                    end = '\n'.ToString();

                SY_sendCmdWithDefineEndTrame(cmd, ref info, end);

                displaySendetCommand(cmd, info.uniqueID);
            }
        }

        private void displaySendetCommand(string cmd, string deviceId)
		{
            string txtAffichage = "";

            txtAffichage = "Send command " + cmd + " to device " + deviceId;

            txtAffichage = "[" + DateTime.Now.ToString("hh:mm:ss - fff") + "] " + txtAffichage;

            if (this.txtInfos.InvokeRequired)
            {
                updateInfo update = new updateInfo(updateTxtInfos);
                this.Invoke(update, new object[] { txtAffichage });
            }
            else
            {
                updateTxtInfos(txtAffichage);
            }
        }

        /**
         * cmbDevice list all the device (dongle or Usb) connected 
         * cmbFounded list all the instrument found by the scan
         * 
         * We use the cmbDevice index to recover the device on which we want to connect the instrument.
         * We use the cmbFounded index to connect the specific bluetooth instrument
         * 
         * Don't mix the variable "indexNumber" and "instrNumber":
         *      - indexNumber: The index of the instrument in the list found or connected
         *      - deviceNumber: A unique number for each device that not change during time unless if you disconnect it
         * 
         */
        private void btnConnect_Click(object sender, EventArgs e)
        {
            //Connect the device at the specified index
            DeviceInfo info = listDevice[cmbDevice.SelectedIndex];
            BTInstrumentAdv instr = getFoundBTInstr(info.deviceNumber, (uint)cmbFounded.SelectedIndex);

            new Thread(() => {
                SY_connectInstr(info.deviceNumber, instr.instrNumber);
            }).Start();
        }

        private void btnDisconnect_Click(object sender, EventArgs e)
        {
            if (cmbConnectedInstr.SelectedIndex != -1)
            {
                DeviceInfo info = listDevice[cmbDevice.SelectedIndex];

                BTInstrumentAdv instr = getInstrFromDongle(info.deviceNumber, (uint)cmbConnectedInstr.SelectedIndex);

                SY_disconnectInstr(info.deviceNumber, instr.instrNumber, true);
            }
            else {
                DeviceInfo device = listDevice[cmbDevice.SelectedIndex];
                SY_disconnect(ref device);      
            }
        }

        private void btnSetParam_Click(object sender, EventArgs e)
        {
            inputScan.Show();
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            if(cmbDevice.SelectedIndex >= 0)
                SY_stopScan(listDevice[cmbDevice.SelectedIndex].deviceNumber);
        }

        private void btnSendAll_Click(object sender, EventArgs e)
        {
            string cmd = txtCmd.Text;

            for (int i = 0; i < listDevice.Count; i++ )
            {
                DeviceInfo info = listDevice[i];

                if (isBleDevice(info.type))
                {
                    uint nbInstrOnDongle = SY_getNumberInstrConnectedByDongle(info.deviceNumber);

                    for (uint j = 0; j < nbInstrOnDongle; j++) {
                        BTInstrumentAdv bt = new BTInstrumentAdv();
                        SY_getBTInstrAdvFromDongle(info.deviceNumber, j, out bt);

                        SY_sendCmd(cmd, ref info, (int)bt.instrNumber);
                    }
                } else {
                    SY_sendCmd(cmd, ref info);
                }

                Thread.Sleep(100);
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            DeviceInfo info = listDevice[cmbDevice.SelectedIndex];
            SY_resetDongle(info.deviceNumber);
        }

        private void btnListing_Click(object sender, EventArgs e)
        {
            string s = "";
            for (int i = 0; i < listDevice.Count; i++) {
                s += SY_toString(listDevice[i].deviceNumber) + Environment.NewLine;
            }

            if (this.txtInfos.InvokeRequired)
            {
                updateInfo update = new updateInfo(updateTxtInfos);
                this.Invoke(update, new object[] { s }); 
            }
            else
            {
                updateTxtInfos(s);
            }
        }

        private void btnChangeParam_Click(object sender, EventArgs e) {
            Form3 formParamChange = new Form3(this);
            formParamChange.Show();
        }

        public void changeParamForCurrentDevice(ParamBaudRate baud, ParamParity parity, ParamByteSize byteSize, ParamStopBit stop) {
            if (cmbDevice.SelectedIndex < 0)
                return;

            DeviceInfo info = listDevice[cmbDevice.SelectedIndex];

            if (!SY_changeParamCommunication(ref info, baud, byteSize, parity, stop)) {
                Console.WriteLine("Change param goes wrong");
            }
        }
    }
}
