﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TestDLLCSharp {
    public partial class Form3 : Form {

        private FrmMain parent;

        public Form3(FrmMain parent) {
            InitializeComponent();
            fillComboBox(cmbBaudrate, (int [])Enum.GetValues(typeof(ParamBaudRate)));
            fillComboBox(cmbBits, (int[])Enum.GetValues(typeof(ParamByteSize)));
            fillComboBox(cmbStopBits, (int[])Enum.GetValues(typeof(ParamStopBit)));

            foreach (string val in Enum.GetNames(typeof(ParamParity))) {
                cmbParity.Items.Add(val);
            }

            this.parent = parent;
        }

        private void fillComboBox(ComboBox cmb, int [] values) { 
            foreach(int val in values){
                cmb.Items.Add(val);
            }
        }

        private void btnValidate_Click(object sender, EventArgs e) {
            ParamBaudRate baudate = ((ParamBaudRate [])Enum.GetValues(typeof(ParamBaudRate)))[cmbBaudrate.SelectedIndex];
            ParamParity parity = ((ParamParity[])Enum.GetValues(typeof(ParamParity)))[cmbParity.SelectedIndex];
            ParamByteSize byteSize = ((ParamByteSize[])Enum.GetValues(typeof(ParamByteSize)))[cmbBits.SelectedIndex];
            ParamStopBit stopBits = ((ParamStopBit[])Enum.GetValues(typeof(ParamStopBit)))[cmbStopBits.SelectedIndex];

            parent.changeParamForCurrentDevice(baudate, parity, byteSize, stopBits);

            this.Hide();
        }
    }
}
