﻿namespace TestDLLCSharp
{
    partial class InputBox
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOk = new System.Windows.Forms.Button();
            this.rdbAllTime = new System.Windows.Forms.RadioButton();
            this.rdbTime = new System.Windows.Forms.RadioButton();
            this.rdbAddress = new System.Windows.Forms.RadioButton();
            this.grbScan = new System.Windows.Forms.GroupBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.txtArg = new System.Windows.Forms.TextBox();
            this.grbScan.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnOk
            // 
            this.btnOk.Location = new System.Drawing.Point(160, 89);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(75, 23);
            this.btnOk.TabIndex = 0;
            this.btnOk.Text = "Ok";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // rdbAllTime
            // 
            this.rdbAllTime.AutoSize = true;
            this.rdbAllTime.Location = new System.Drawing.Point(18, 19);
            this.rdbAllTime.Name = "rdbAllTime";
            this.rdbAllTime.Size = new System.Drawing.Size(58, 17);
            this.rdbAllTime.TabIndex = 1;
            this.rdbAllTime.Text = "All time";
            this.rdbAllTime.UseVisualStyleBackColor = true;
            this.rdbAllTime.CheckedChanged += new System.EventHandler(this.rdbAllTime_CheckedChanged);
            // 
            // rdbTime
            // 
            this.rdbTime.AutoSize = true;
            this.rdbTime.Checked = true;
            this.rdbTime.Location = new System.Drawing.Point(18, 42);
            this.rdbTime.Name = "rdbTime";
            this.rdbTime.Size = new System.Drawing.Size(48, 17);
            this.rdbTime.TabIndex = 2;
            this.rdbTime.TabStop = true;
            this.rdbTime.Text = "Time";
            this.rdbTime.UseVisualStyleBackColor = true;
            this.rdbTime.CheckedChanged += new System.EventHandler(this.rdbTime_CheckedChanged);
            // 
            // rdbAddress
            // 
            this.rdbAddress.AutoSize = true;
            this.rdbAddress.Location = new System.Drawing.Point(18, 65);
            this.rdbAddress.Name = "rdbAddress";
            this.rdbAddress.Size = new System.Drawing.Size(78, 17);
            this.rdbAddress.TabIndex = 3;
            this.rdbAddress.Text = "By Address";
            this.rdbAddress.UseVisualStyleBackColor = true;
            this.rdbAddress.CheckedChanged += new System.EventHandler(this.rdbAddress_CheckedChanged);
            // 
            // grbScan
            // 
            this.grbScan.Controls.Add(this.rdbAllTime);
            this.grbScan.Controls.Add(this.rdbAddress);
            this.grbScan.Controls.Add(this.rdbTime);
            this.grbScan.Location = new System.Drawing.Point(12, 12);
            this.grbScan.Name = "grbScan";
            this.grbScan.Size = new System.Drawing.Size(121, 100);
            this.grbScan.TabIndex = 4;
            this.grbScan.TabStop = false;
            this.grbScan.Text = "Scan type";
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(258, 89);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 5;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // txtArg
            // 
            this.txtArg.Location = new System.Drawing.Point(160, 31);
            this.txtArg.Name = "txtArg";
            this.txtArg.Size = new System.Drawing.Size(173, 20);
            this.txtArg.TabIndex = 6;
            this.txtArg.Visible = false;
            this.txtArg.TextChanged += new System.EventHandler(this.txtArg_TextChanged);
            // 
            // InputBox
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(345, 129);
            this.Controls.Add(this.txtArg);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.grbScan);
            this.Controls.Add(this.btnOk);
            this.Name = "InputBox";
            this.Text = "InputBox";
            this.grbScan.ResumeLayout(false);
            this.grbScan.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.RadioButton rdbAllTime;
        private System.Windows.Forms.RadioButton rdbTime;
        private System.Windows.Forms.RadioButton rdbAddress;
        private System.Windows.Forms.GroupBox grbScan;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.TextBox txtArg;
    }
}