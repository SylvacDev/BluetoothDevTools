﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TestDLLCSharp
{
    public partial class InputBox : Form
    {

        private TypeScan type;
        private string arg;
        private FrmMain parent;

        public InputBox()
        {
            InitializeComponent();
            type = TypeScan.SCAN_DURING_TIME;
            arg = "20000";
            txtArg.Text = arg;
            txtArg.Visible = true;
            btnOk.Enabled = true;
        }

        private void rdbAllTime_CheckedChanged(object sender, EventArgs e)
        {
            txtArg.Visible = false;
            btnOk.Enabled = true;
            type = TypeScan.SCAN_DURING_ALL_TIME;
        }

        private void rdbTime_CheckedChanged(object sender, EventArgs e)
        {
            txtArg.Visible = true;
            type = TypeScan.SCAN_DURING_TIME;
        }

        private void rdbAddress_CheckedChanged(object sender, EventArgs e)
        {
            txtArg.Visible = true;
            type = TypeScan.SCAN_BY_ADDRESS;
        }

        private void txtArg_TextChanged(object sender, EventArgs e)
        {
            btnOk.Enabled = txtArg.Text != "";
            arg = txtArg.Text;
        }

        public TypeScan getType() {
            return type;
        }

        public string getArg() {
            return arg;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Visible = false;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            this.Visible = false;
        }
    }
}
