"""asyncio support: the events of a `BleManager` as an asynchronous iterator.

Use `BleManager.events_async()`, which calls `events` below.
"""

from __future__ import annotations

import asyncio
import functools
from collections.abc import AsyncIterator, Awaitable, Callable
from typing import Any, TypeVar

from ._native import BleManager, Event, StoppedError

T = TypeVar("T")


def in_executor(function: Callable[..., T], args: tuple[Any, ...]) -> Awaitable[T]:
    """`function(*args)` in the running loop's default executor (a thread): the `*_async`
    waiting calls of `BleManager` and `BlePeripheral`. The waiting call releases the GIL, so the
    loop runs meanwhile. Cancelling the awaitable does not stop the request."""
    return asyncio.get_running_loop().run_in_executor(None, functools.partial(function, *args))

__all__ = ["events", "in_executor"]


async def events(manager: BleManager) -> AsyncIterator[Event]:
    """Yields the events of `manager` in the running event loop.

    The library thread hands each event to the loop (`call_soon_threadsafe`), so the loop is
    never blocked. Events still in the manager's queue come first. The iterator ends when the
    manager stops (on a stopped manager it only gives the events still queued); when it is
    closed, events go to the queue again. Leaving an `async for` with `break` does not close it
    at once: wrap it in `contextlib.aclosing` to be sure. It uses the manager's callback: do not
    call `set_callback` or `next_event` meanwhile.
    """
    loop = asyncio.get_running_loop()
    queue: asyncio.Queue[Event | None] = asyncio.Queue()

    def put(item: Event | None) -> None:
        # On the library thread.
        try:
            loop.call_soon_threadsafe(queue.put_nowait, item)
        except RuntimeError:
            pass  # the loop is closed: nobody is listening any more

    try:
        manager._set_callback(put, lambda: put(None))
    except StoppedError:
        # Already stopped: only the events still queued.
        for event in manager.events():
            yield event
        return
    try:
        while True:
            item = await queue.get()
            if item is None:
                return
            yield item
    finally:
        try:
            manager.set_callback(None)
        except StoppedError:
            pass
