"""Connect Sylvac instruments through Sylvac Bluetooth dongles (BLED112, Bt5Smart).

`BleManager()` starts the library on its own thread: it finds the dongles, spreads the instruments
over them, reconnects instruments that drop, and reports everything as events. Calls return at
once; their results come back as events::

    import sylvac_ble

    with sylvac_ble.BleManager() as manager:
        manager.scan.sylvac_only = True
        manager.scan.start()
        manager.start_connect("D216182F6CCC")
        params = None                           # always reported before the values
        for event in manager.events():          # Ctrl+C ends the loop
            match event:
                case sylvac_ble.ConnectionStepChanged(
                    peripheral=mac, value=sylvac_ble.ConnectionStep.SUBSCRIBED
                ):
                    manager.peripheral(mac).send_command("?")
                case sylvac_ble.MeasurementParamsChanged(value=params):
                    pass
                case sylvac_ble.NumericalValueChanged(peripheral=mac, value=value) if params:
                    print(mac, params.format(value), params.unit.name)
                case sylvac_ble.InstrumentResponseReceived(peripheral=mac, value=text):
                    print(mac, "answered", text)

Events can also be taken one at a time (`BleManager.next_event`), given to a callback
(`BleManager.set_callback`) or read with asyncio (`BleManager.events_async`).
"""

from ._native import (
    AdvertiserChanged,
    AdvertiserRemoved,
    BleAdvertiser,
    BleCentral,
    BleManager,
    BlePeripheral,
    BleScan,
    BondedMacsListChanged,
    BondMode,
    CentralAdded,
    CentralFailed,
    CentralKind,
    CentralRemoved,
    CentralToConnectChanged,
    CommandDroppedError,
    Connecting,
    ConnectionStep,
    ConnectionStepChanged,
    DeviceUsageType,
    Disconnected,
    DisconnectReason,
    Event,
    EventIterator,
    InstrumentButtonPressed,
    InstrumentCommandDropped,
    InstrumentResponseReceived,
    InstrumentResponseTimeout,
    LibLog,
    LogLevel,
    MeasurementParamsChanged,
    MeasuringParams,
    NoResponseError,
    NumericalValueChanged,
    Overflow,
    PairingStatus,
    PairingStatusChanged,
    PeripheralAdded,
    PeripheralRemoved,
    Rejected,
    RejectedError,
    RejectReason,
    ReleasedError,
    SdsMode,
    SdsResolution,
    SdsUnit,
    StartError,
    StoppedError,
    SylvacBleError,
    __version__,
)

__all__ = [
    "AdvertiserChanged",
    "AdvertiserRemoved",
    "BleAdvertiser",
    "BleCentral",
    "BleManager",
    "BlePeripheral",
    "BleScan",
    "BondedMacsListChanged",
    "BondMode",
    "CentralAdded",
    "CentralFailed",
    "CentralKind",
    "CentralRemoved",
    "CentralToConnectChanged",
    "CommandDroppedError",
    "Connecting",
    "ConnectionStep",
    "ConnectionStepChanged",
    "DeviceUsageType",
    "Disconnected",
    "DisconnectReason",
    "Event",
    "EventIterator",
    "InstrumentButtonPressed",
    "InstrumentCommandDropped",
    "InstrumentResponseReceived",
    "InstrumentResponseTimeout",
    "LibLog",
    "LogLevel",
    "MeasurementParamsChanged",
    "MeasuringParams",
    "NoResponseError",
    "NumericalValueChanged",
    "Overflow",
    "PairingStatus",
    "PairingStatusChanged",
    "PeripheralAdded",
    "PeripheralRemoved",
    "Rejected",
    "RejectedError",
    "RejectReason",
    "ReleasedError",
    "SdsMode",
    "SdsResolution",
    "SdsUnit",
    "StartError",
    "StoppedError",
    "SylvacBleError",
    "__version__",
]
