"""Types of the native module. Checked against the module by tests/test_stubs.py (stubtest)."""

from collections.abc import AsyncIterator, Callable, Sequence
from datetime import datetime
from types import TracebackType
from typing import ClassVar, Final, final

from typing_extensions import Self

__all__ = [
    "_sample_events",
    "_stop_all",
    "AdvertiserChanged",
    "AdvertiserRemoved",
    "BleAdvertiser",
    "BleCentral",
    "BleManager",
    "BlePeripheral",
    "BleScan",
    "BondedMacsListChanged",
    "BondMode",
    "CentralAdded",
    "CentralFailed",
    "CentralKind",
    "CentralRemoved",
    "CentralToConnectChanged",
    "CommandDroppedError",
    "Connecting",
    "ConnectionStep",
    "ConnectionStepChanged",
    "DeviceUsageType",
    "Disconnected",
    "DisconnectReason",
    "Event",
    "EventIterator",
    "InstrumentButtonPressed",
    "InstrumentCommandDropped",
    "InstrumentResponseReceived",
    "InstrumentResponseTimeout",
    "LibLog",
    "LogLevel",
    "MeasurementParamsChanged",
    "MeasuringParams",
    "NoResponseError",
    "NumericalValueChanged",
    "Overflow",
    "PairingStatus",
    "PairingStatusChanged",
    "PeripheralAdded",
    "PeripheralRemoved",
    "Rejected",
    "RejectedError",
    "RejectReason",
    "ReleasedError",
    "SdsMode",
    "SdsResolution",
    "SdsUnit",
    "StartError",
    "StoppedError",
    "SylvacBleError",
    "__version__",
]

__version__: Final[str]

class SylvacBleError(Exception):
    """Base class of the errors of this package."""

class StoppedError(SylvacBleError):
    """The manager is stopped; from `next_event`: stopped and every event was taken."""

class RejectedError(SylvacBleError):
    """A waiting call was refused (the `Rejected` event)."""

    reason: RejectReason

class NoResponseError(SylvacBleError):
    """`send_and_wait`: the instrument did not answer within the library's response
    timeout."""

class CommandDroppedError(SylvacBleError):
    """`send_and_wait`: the command was dropped (link down or instrument released)."""

class ReleasedError(SylvacBleError):
    """`connect`: the instrument was released before it was connected."""

class StartError(SylvacBleError):
    """The library could not start (its thread, its runtime or the serial port watcher)."""

# ----------------------------------------------------------------------------------------------
# Enumerations. Members compare with `==` (also to their number) and can be dictionary keys;
# `int(member)` and `member.value` are the numbers of the C library. Not `enum.Enum` members.

@final
class CentralKind:
    """Model of a Sylvac dongle."""

    UNKNOWN: ClassVar[CentralKind]
    BLED112: ClassVar[CentralKind]
    BT5_SMART: ClassVar[CentralKind]
    @property
    def name(self) -> str: ...
    @property
    def value(self) -> int: ...
    def __int__(self) -> int: ...

@final
class DeviceUsageType:
    """What an advertiser is, from its name."""

    UNKNOWN: ClassVar[DeviceUsageType]
    INSTRUMENT: ClassVar[DeviceUsageType]
    PEDAL: ClassVar[DeviceUsageType]
    @property
    def name(self) -> str: ...
    @property
    def value(self) -> int: ...
    def __int__(self) -> int: ...

@final
class BondMode:
    """Bond mode an instrument advertises."""

    UNDEFINED: ClassVar[BondMode]
    BONDABLE_BONDED: ClassVar[BondMode]
    BONDABLE_NOT_BONDED: ClassVar[BondMode]
    NON_BONDABLE: ClassVar[BondMode]
    @property
    def name(self) -> str: ...
    @property
    def value(self) -> int: ...
    def __int__(self) -> int: ...

@final
class SdsUnit:
    """Unit of an instrument value."""

    UNDEFINED: ClassVar[SdsUnit]
    MILLIMETER: ClassVar[SdsUnit]
    INCH: ClassVar[SdsUnit]
    RADIAN: ClassVar[SdsUnit]
    DEGREE: ClassVar[SdsUnit]
    DEGREE_MINUTE: ClassVar[SdsUnit]
    @property
    def name(self) -> str: ...
    @property
    def value(self) -> int: ...
    def __int__(self) -> int: ...

@final
class SdsMode:
    """Measuring mode of an instrument."""

    NORMAL: ClassVar[SdsMode]
    MIN: ClassVar[SdsMode]
    MAX: ClassVar[SdsMode]
    DELTA: ClassVar[SdsMode]
    @property
    def name(self) -> str: ...
    @property
    def value(self) -> int: ...
    def __int__(self) -> int: ...

@final
class SdsResolution:
    """Resolution class an instrument displays.

    A code the protocol does not define is reported as `UNDEFINED`.
    """

    UNDEFINED: ClassVar[SdsResolution]
    MINUS1: ClassVar[SdsResolution]
    MINUS2: ClassVar[SdsResolution]
    MINUS3: ClassVar[SdsResolution]
    MINUS4: ClassVar[SdsResolution]
    MINUS5: ClassVar[SdsResolution]
    @property
    def name(self) -> str: ...
    @property
    def value(self) -> int: ...
    def __int__(self) -> int: ...

@final
class LogLevel:
    """Severity of a `LibLog`, and the threshold `log_level` of `BleManager`. A message is sent
    when its level is at or below the threshold; `NONE` as threshold sends none.
    """

    NONE: ClassVar[LogLevel]
    ERROR: ClassVar[LogLevel]
    WARNING: ClassVar[LogLevel]
    INFO: ClassVar[LogLevel]
    DEBUG: ClassVar[LogLevel]
    @property
    def name(self) -> str: ...
    @property
    def value(self) -> int: ...
    def __int__(self) -> int: ...

@final
class ConnectionStep:
    """How far the link of an instrument has got."""

    NONE: ClassVar[ConnectionStep]
    ESTABLISHED: ClassVar[ConnectionStep]
    DISCOVERING: ClassVar[ConnectionStep]
    DISCOVERED: ClassVar[ConnectionStep]
    SUBSCRIBING: ClassVar[ConnectionStep]
    SUBSCRIBED: ClassVar[ConnectionStep]
    @property
    def name(self) -> str: ...
    @property
    def value(self) -> int: ...
    def __int__(self) -> int: ...

@final
class DisconnectReason:
    """Why an instrument link went down."""

    REQUESTED: ClassVar[DisconnectReason]
    LINK: ClassVar[DisconnectReason]
    DONGLE_LOST: ClassVar[DisconnectReason]
    @property
    def name(self) -> str: ...
    @property
    def value(self) -> int: ...
    def __int__(self) -> int: ...

@final
class RejectReason:
    """Why a request about an instrument was not carried out."""

    ALL_CENTRALS_FULL: ClassVar[RejectReason]
    NOT_CONNECTED: ClassVar[RejectReason]
    NOT_READY: ClassVar[RejectReason]
    CENTRAL_REFUSED: ClassVar[RejectReason]
    CENTRAL_FULL: ClassVar[RejectReason]
    UNKNOWN_CENTRAL: ClassVar[RejectReason]
    NO_BOND: ClassVar[RejectReason]
    @property
    def name(self) -> str: ...
    @property
    def value(self) -> int: ...
    def __int__(self) -> int: ...

# ----------------------------------------------------------------------------------------------
# Snapshot records (read-only)

@final
class MeasuringParams:
    """How the instrument measures, from its SDS Parameters."""

    __match_args__: Final = ("unit", "measuring_mode", "numerical_resolution", "resolution_class")
    def __new__(
        cls,
        unit: SdsUnit,
        measuring_mode: SdsMode,
        numerical_resolution: int,
        resolution_class: SdsResolution,
    ) -> Self: ...
    @property
    def unit(self) -> SdsUnit:
        """The unit of the `NumericalValueChanged` values."""
    @property
    def measuring_mode(self) -> SdsMode: ...
    @property
    def numerical_resolution(self) -> int:
        """Decimals of the values: the resolution class, + 2 in inch and radian, at most 15."""
    @property
    def resolution_class(self) -> SdsResolution: ...
    def format(self, value: float) -> str:
        """`value` with exactly `numerical_resolution` decimals, never `-0.000`.

        The text the instrument shows for a `NumericalValueChanged` value. A non-finite value
        gives `NaN`, `inf` or `-inf`.
        """

@final
class PairingStatus:
    """Encryption state of an instrument's link."""

    __match_args__: Final = ("is_paired", "is_bonded")
    def __new__(cls, is_paired: bool, is_bonded: bool) -> Self: ...
    @property
    def is_paired(self) -> bool:
        """The link is encrypted."""
    @property
    def is_bonded(self) -> bool:
        """The dongle keeps the keys for the next links."""

@final
class BleCentral:
    """A dongle that finished its initialisation (`BleManager.centrals()`)."""

    __match_args__: Final = (
        "port_name",
        "mac",
        "kind",
        "version",
        "build",
        "max_conn",
        "bonded_macs",
        "peripherals",
    )
    def __new__(
        cls,
        port_name: str,
        mac: str,
        kind: CentralKind,
        version: str,
        build: int,
        max_conn: int,
        bonded_macs: list[str],
        peripherals: list[str],
    ) -> Self: ...
    @property
    def port_name(self) -> str:
        """`COM5`, `/dev/ttyACM0`, `/dev/ttyS2`."""
    @property
    def mac(self) -> str:
        """Bluetooth address, 12 upper-case hex digits."""
    @property
    def kind(self) -> CentralKind: ...
    @property
    def version(self) -> str:
        """Firmware version, `major.minor.patch`."""
    @property
    def build(self) -> int:
        """Firmware build number."""
    @property
    def max_conn(self) -> int:
        """Simultaneous connections the dongle supports."""
    @property
    def bonded_macs(self) -> list[str]:
        """Instruments bonded to this dongle, as read at its start; emptied by
        `BleManager.reset_connections`."""
    @property
    def peripherals(self) -> list[str]:
        """Instruments placed on this dongle, linked or not, in MAC order; empty in
        `CentralAdded`."""
    @property
    def is_full(self) -> bool:
        """As many instruments placed as connections;
        `start_connect(mac, central=...)` is then refused with `RejectReason.CENTRAL_FULL`."""

@final
class BleAdvertiser:
    """A device heard by the scanning dongle in the last 60 s (`BleManager.scan.advertisers()`)."""

    __match_args__: Final = (
        "mac",
        "name",
        "rssi",
        "value",
        "float_value",
        "battery",
        "article_number",
        "bond_mode",
        "bonded_to_dongle",
        "date_received",
    )
    def __new__(
        cls,
        mac: str,
        name: str | None,
        rssi: int,
        value: str | None,
        float_value: float | None,
        battery: int | None,
        article_number: str | None,
        bond_mode: BondMode,
        bonded_to_dongle: bool,
        date_received: datetime,
    ) -> Self: ...
    @property
    def mac(self) -> str:
        """Bluetooth address, 12 upper-case hex digits."""
    @property
    def name(self) -> str | None:
        """Last name advertised, `None` when none was heard."""
    @property
    def rssi(self) -> int:
        """Signal strength of the last packet, dBm."""
    @property
    def value(self) -> str | None:
        """Advertised value as text, `None` when the device sends none."""
    @property
    def float_value(self) -> float | None:
        """The same value as a number, `None` when the device sends none."""
    @property
    def battery(self) -> int | None:
        """Battery level in %, `None` when not advertised."""
    @property
    def article_number(self) -> str | None:
        """Article number (DIS Model Number String), the last one advertised, or `None`."""
    @property
    def bond_mode(self) -> BondMode: ...
    @property
    def bonded_to_dongle(self) -> bool:
        """The scanning dongle holds a bond for this device."""
    @property
    def date_received(self) -> datetime:
        """When its last packet was heard, timezone-aware UTC.

        `AdvertiserChanged` is not sent for this alone.
        """
    @property
    def device_usage_type(self) -> DeviceUsageType:
        """`PEDAL` for a name starting with `SYSW`, `UNKNOWN` before a name is heard, else
        `INSTRUMENT`."""
    @property
    def is_low_battery(self) -> bool:
        """A battery level is advertised, above 0 and below 20 %."""
    @property
    def is_bonded(self) -> bool:
        """`bond_mode` is `BondMode.BONDABLE_BONDED`."""
    @property
    def is_bonded_to_another(self) -> bool:
        """Bonded, but not to the scanning dongle.

        Connecting it from this dongle cannot encrypt the link.
        """

# ----------------------------------------------------------------------------------------------
# Events (read-only)

class Event:
    """Base class of everything the manager reports.

    Every event is an instance of one of its subclasses; test with `isinstance` or `match`.
    Later versions can add subclasses: ignore those you do not know.
    """

@final
class CentralAdded(Event):
    """A dongle is ready to use."""

    __match_args__: Final = (
        "port_name",
        "mac",
        "kind",
        "version",
        "build",
        "max_conn",
        "bonded_macs",
        "peripherals",
    )
    def __new__(
        cls,
        port_name: str,
        mac: str,
        kind: CentralKind,
        version: str,
        build: int,
        max_conn: int,
        bonded_macs: list[str],
        peripherals: list[str],
    ) -> Self: ...
    @property
    def port_name(self) -> str:
        """`COM5`, `/dev/ttyACM0`, `/dev/ttyS2`."""
    @property
    def mac(self) -> str:
        """Bluetooth address, 12 upper-case hex digits."""
    @property
    def kind(self) -> CentralKind: ...
    @property
    def version(self) -> str:
        """Firmware version, `major.minor.patch`."""
    @property
    def build(self) -> int:
        """Firmware build number."""
    @property
    def max_conn(self) -> int:
        """Simultaneous connections the dongle supports."""
    @property
    def bonded_macs(self) -> list[str]:
        """Instruments bonded to this dongle, as read at its start; emptied by
        `BleManager.reset_connections`."""
    @property
    def peripherals(self) -> list[str]:
        """Instruments placed on this dongle, linked or not, in MAC order; empty in
        `CentralAdded`."""
    @property
    def is_full(self) -> bool:
        """As many instruments placed as connections;
        `start_connect(mac, central=...)` is then refused with `RejectReason.CENTRAL_FULL`."""

@final
class CentralRemoved(Event):
    """A ready dongle went away."""

    __match_args__: Final = ("port_name", "mac", "error")
    def __new__(cls, port_name: str, mac: str, error: str | None) -> Self: ...
    @property
    def port_name(self) -> str: ...
    @property
    def mac(self) -> str: ...
    @property
    def error(self) -> str | None:
        """Why, `None` after a requested stop."""

@final
class CentralFailed(Event):
    """A dongle port could not be opened or initialised (busy port, not a dongle...).

    Retried every 5 s while the port is present; reported again only when the error changes.
    """

    __match_args__: Final = ("port_name", "error")
    def __new__(cls, port_name: str, error: str) -> Self: ...
    @property
    def port_name(self) -> str: ...
    @property
    def error(self) -> str: ...

@final
class AdvertiserChanged(Event):
    """A device heard while scanning: new, changed, or refreshed at most once a second."""

    __match_args__: Final = (
        "mac",
        "name",
        "rssi",
        "value",
        "float_value",
        "battery",
        "article_number",
        "bond_mode",
        "bonded_to_dongle",
        "date_received",
    )
    def __new__(
        cls,
        mac: str,
        name: str | None,
        rssi: int,
        value: str | None,
        float_value: float | None,
        battery: int | None,
        article_number: str | None,
        bond_mode: BondMode,
        bonded_to_dongle: bool,
        date_received: datetime,
    ) -> Self: ...
    @property
    def mac(self) -> str:
        """Bluetooth address, 12 upper-case hex digits."""
    @property
    def name(self) -> str | None:
        """Last name advertised, `None` when none was heard."""
    @property
    def rssi(self) -> int:
        """Signal strength of the last packet, dBm."""
    @property
    def value(self) -> str | None:
        """Advertised value as text, `None` when the device sends none."""
    @property
    def float_value(self) -> float | None:
        """The same value as a number, `None` when the device sends none."""
    @property
    def battery(self) -> int | None:
        """Battery level in %, `None` when not advertised."""
    @property
    def article_number(self) -> str | None:
        """Article number (DIS Model Number String), the last one advertised, or `None`."""
    @property
    def bond_mode(self) -> BondMode: ...
    @property
    def bonded_to_dongle(self) -> bool:
        """The scanning dongle holds a bond for this device."""
    @property
    def date_received(self) -> datetime:
        """When its last packet was heard, timezone-aware UTC.

        `AdvertiserChanged` is not sent for this alone.
        """
    @property
    def device_usage_type(self) -> DeviceUsageType:
        """`PEDAL` for a name starting with `SYSW`, `UNKNOWN` before a name is heard, else
        `INSTRUMENT`."""
    @property
    def is_low_battery(self) -> bool:
        """A battery level is advertised, above 0 and below 20 %."""
    @property
    def is_bonded(self) -> bool:
        """`bond_mode` is `BondMode.BONDABLE_BONDED`."""
    @property
    def is_bonded_to_another(self) -> bool:
        """Bonded, but not to the scanning dongle.

        Connecting it from this dongle cannot encrypt the link.
        """

@final
class AdvertiserRemoved(Event):
    """A device was not heard for 60 s."""

    __match_args__: Final = ("mac",)
    def __new__(cls, mac: str) -> Self: ...
    @property
    def mac(self) -> str: ...

@final
class PeripheralAdded(Event):
    """An instrument joined the manager's list (`BleManager.peripherals()`): a `start_connect`
    accepted for an instrument not in it. Before any other event about it."""

    __match_args__: Final = ("peripheral",)
    def __new__(cls, peripheral: str) -> Self: ...
    @property
    def peripheral(self) -> str:
        """Address of the instrument."""

@final
class PeripheralRemoved(Event):
    """An instrument left the manager's list: `BlePeripheral.start_disconnect()`,
    `reset_connections`, `stop`, or no dongle could take it (`Rejected` with
    `RejectReason.ALL_CENTRALS_FULL` after its `PeripheralAdded`). The last event about it
    until it is asked for again."""

    __match_args__: Final = ("peripheral",)
    def __new__(cls, peripheral: str) -> Self: ...
    @property
    def peripheral(self) -> str:
        """Address of the instrument."""

@final
class Connecting(Event):
    """A link attempt started (repeated by the automatic reconnection)."""

    __match_args__: Final = ("peripheral", "central")
    def __new__(cls, peripheral: str, central: str) -> Self: ...
    @property
    def peripheral(self) -> str:
        """Address of the instrument."""
    @property
    def central(self) -> str:
        """Address of the dongle."""

@final
class CentralToConnectChanged(Event):
    """The dongle the instrument is assigned to changed: its first placement, a reassignment
    after a dongle loss, or `None` while it waits for a free slot or for its own dongle, and
    when it is disconnected.
    """

    __match_args__: Final = ("peripheral", "old_value", "new_value")
    def __new__(cls, peripheral: str, old_value: str | None, new_value: str | None) -> Self: ...
    @property
    def peripheral(self) -> str:
        """Address of the instrument."""
    @property
    def old_value(self) -> str | None:
        """Address of the previous dongle, `None` when there was none."""
    @property
    def new_value(self) -> str | None:
        """Address of the dongle now, `None` when there is none."""

@final
class BondedMacsListChanged(Event):
    """The bonds of a dongle changed: a link bonded (`added`), a bond went (`removed`:
    `delete_bond` once the dongle confirms, `reset_connections`). The new list is the
    dongle's `bonded_macs` in `centrals()`.
    """

    __match_args__: Final = ("central", "added", "removed")
    def __new__(cls, central: str, added: list[str], removed: list[str]) -> Self: ...
    @property
    def central(self) -> str:
        """Address of the dongle."""
    @property
    def added(self) -> list[str]:
        """Instruments bonded since the last change."""
    @property
    def removed(self) -> list[str]:
        """Instruments no longer bonded."""

@final
class ConnectionStepChanged(Event):
    """The link reached `value`: `ESTABLISHED`, `DISCOVERING`,
    `DISCOVERED`, `SUBSCRIBING`, `SUBSCRIBED` in order, each once per link, then `NONE` when
    the link goes down (right before `Disconnected`, which only follows a link that reached
    `SUBSCRIBED`). At `SUBSCRIBED` values arrive and commands can be sent. The dongle is
    `BlePeripheral.central_to_connect_mac`; live values: `BlePeripheral.has_live_values`.
    """

    __match_args__: Final = ("peripheral", "value")
    def __new__(cls, peripheral: str, value: ConnectionStep) -> Self: ...
    @property
    def peripheral(self) -> str:
        """Address of the instrument."""
    @property
    def value(self) -> ConnectionStep: ...

@final
class PairingStatusChanged(Event):
    """The link's encryption changed.

    Kept when the link goes down; a bonding failure sets both flags to false.
    """

    __match_args__: Final = ("peripheral", "value")
    def __new__(cls, peripheral: str, value: PairingStatus) -> Self: ...
    @property
    def peripheral(self) -> str:
        """Address of the instrument."""
    @property
    def value(self) -> PairingStatus: ...

@final
class MeasurementParamsChanged(Event):
    """The instrument's measuring parameters became known or changed.

    Always before the first `NumericalValueChanged` in them: after `IN` on a millimetre
    instrument, this event in inch, then values in inch. Kept across links.
    """

    __match_args__: Final = ("peripheral", "value")
    def __new__(cls, peripheral: str, value: MeasuringParams) -> Self: ...
    @property
    def peripheral(self) -> str:
        """Address of the instrument."""
    @property
    def value(self) -> MeasuringParams: ...

@final
class NumericalValueChanged(Event):
    """Live value and the `measurement_params` it is in.

    In their unit and rounded to their `numerical_resolution`;
    `measurement_params.format(value)` shows it as the instrument does. The same parameters as
    the last `MeasurementParamsChanged`, sent before this event when they changed; carried here
    so that each value can be shown without keeping them. Not filtered: an SY289 with firmware
    r4.10r sends 100 x the real value as its first measurement after each connection.
    """

    __match_args__: Final = ("peripheral", "value", "measurement_params")
    def __new__(cls, peripheral: str, value: float, measurement_params: MeasuringParams) -> Self: ...
    @property
    def peripheral(self) -> str: ...
    @property
    def value(self) -> float: ...
    @property
    def measurement_params(self) -> MeasuringParams:
        """The parameters `value` is in."""

@final
class InstrumentButtonPressed(Event):
    """The instrument's Data button was pressed."""

    __match_args__: Final = ("peripheral", "value")
    def __new__(cls, peripheral: str, value: str) -> Self: ...
    @property
    def peripheral(self) -> str: ...
    @property
    def value(self) -> str:
        """The line as received (usually the displayed value)."""

@final
class InstrumentResponseReceived(Event):
    """A reply line."""

    __match_args__: Final = ("peripheral", "value", "command")
    def __new__(cls, peripheral: str, value: str, command: str | None) -> Self: ...
    @property
    def peripheral(self) -> str: ...
    @property
    def value(self) -> str:
        """The reply line."""
    @property
    def command(self) -> str | None:
        """The command it answers (the oldest one without a reply), `None` when none was waiting."""

@final
class InstrumentResponseTimeout(Event):
    """No reply within the reply timeout.

    Setting commands (`MM`, `IN`, ...) are normally silent, so this is their usual outcome.
    """

    __match_args__: Final = ("peripheral", "command")
    def __new__(cls, peripheral: str, command: str) -> Self: ...
    @property
    def peripheral(self) -> str: ...
    @property
    def command(self) -> str: ...

@final
class InstrumentCommandDropped(Event):
    """The link went down before the command was answered."""

    __match_args__: Final = ("peripheral", "command")
    def __new__(cls, peripheral: str, command: str) -> Self: ...
    @property
    def peripheral(self) -> str: ...
    @property
    def command(self) -> str: ...

@final
class Disconnected(Event):
    """The link went down."""

    __match_args__: Final = ("peripheral", "reason", "link_code", "reconnecting")
    def __new__(
        cls, peripheral: str, reason: DisconnectReason, link_code: int | None, reconnecting: bool
    ) -> Self: ...
    @property
    def peripheral(self) -> str: ...
    @property
    def reason(self) -> DisconnectReason: ...
    @property
    def link_code(self) -> int | None:
        """BGAPI reason code when `reason` is `DisconnectReason.LINK` (0x0208 supervision
        timeout, 0x0213 remote user terminated, ...), else `None`."""
    @property
    def reconnecting(self) -> bool:
        """The manager keeps trying to reconnect (until `BlePeripheral.start_disconnect()`)."""

@final
class Rejected(Event):
    """A request about this instrument was not carried out."""

    __match_args__: Final = ("peripheral", "reason")
    def __new__(cls, peripheral: str, reason: RejectReason) -> Self: ...
    @property
    def peripheral(self) -> str: ...
    @property
    def reason(self) -> RejectReason: ...

@final
class LibLog(Event):
    """Something worth logging: `ERROR` (the event callback panicked, serial ports cannot be
    listed) or `WARNING` (mount or bonding failure, dongle protocol error, dongle command
    without response, request refused). Only levels that pass the manager's `log_level` are
    sent; `level` is never `LogLevel.NONE`.
    """

    __match_args__: Final = ("level", "message")
    def __new__(cls, level: LogLevel, message: str) -> Self: ...
    @property
    def level(self) -> LogLevel: ...
    @property
    def message(self) -> str: ...

@final
class Overflow(Event):
    """The event queue was full: `dropped` events were discarded (advertisements first)."""

    __match_args__: Final = ("dropped",)
    def __new__(cls, dropped: int) -> Self: ...
    @property
    def dropped(self) -> int: ...

# ----------------------------------------------------------------------------------------------
# BleManager and instruments

@final
class BlePeripheral:
    """An instrument asked for with `BleManager.start_connect`.

    A cheap handle: keep it, or make one again with `BleManager.peripheral(mac)`. Its calls raise
    `StoppedError` once the manager is stopped.
    """

    @property
    def mac(self) -> str:
        """Its Bluetooth address, 12 upper-case hex digits, as in the events."""
    @property
    def connection_step(self) -> ConnectionStep:
        """The step its link has reached: the last `ConnectionStepChanged`;
        `ConnectionStep.NONE` while not connected, and for an instrument not asked for (or
        disconnected).

        These properties read the state the library thread publishes before it hands out the
        events of each change: an event already taken (or given to the callback), or a waiting
        call that returned, always shows in them; they can be ahead, showing a change whose event
        is still queued.
        """
    @property
    def is_connected(self) -> bool:
        """Subscribed: values arrive and commands can be sent."""
    @property
    def central_to_connect_mac(self) -> str | None:
        """Address of the dongle it is assigned to: the last `CentralToConnectChanged`; `None`
        while it waits for a dongle or once disconnected.
        """
    @property
    def pairing_status(self) -> PairingStatus:
        """The last `PairingStatusChanged`, kept when the link goes down."""
    @property
    def is_paired(self) -> bool:
        """The link is encrypted (`pairing_status.is_paired`)."""
    @property
    def measurement_params(self) -> MeasuringParams | None:
        """The last `MeasurementParamsChanged`, kept across links.

        `None` before the instrument sent its SDS Parameters.
        """
    @property
    def numerical_value(self) -> float:
        """The last `NumericalValueChanged`, kept across links.

        NaN before the first value.
        """
    @property
    def has_live_values(self) -> bool:
        """The current link reached `SUBSCRIBED` and the instrument has the Simple Data Service.

        So it sends live values; false at the other steps.
        """
    @property
    def auto_reassign(self) -> bool:
        """When its dongle goes away, it is reconnected on another dongle with a free slot,
        unless it is bonded (the other dongle could not encrypt the link); otherwise it waits
        for its dongle. Starts as the manager's `auto_reassign`. Setting it is carried out by
        the library thread (an instrument not asked for gets a `Rejected` event).
        """
    @auto_reassign.setter
    def auto_reassign(self, on: bool) -> None: ...
    def send_and_wait(
        self, command: str, timeout: float | None = None, end_of_frame: str | None = None
    ) -> str:
        """`send_command(command)`, then waits up to `timeout` seconds (`None`: until the
        reply, the library's response timeout or a drop) and returns the reply, also the
        `InstrumentResponseReceived` of the queue or callback (given first).
        With `end_of_frame`, the reply ends with that text instead of a carriage return:
        everything before it, as received. Raises `TimeoutError`, `RejectedError`,
        `NoResponseError`, `CommandDroppedError`, `RuntimeError` from the event callback,
        `ValueError` (empty command), `StoppedError`."""
    async def send_and_wait_async(
        self, command: str, timeout: float | None = None, end_of_frame: str | None = None
    ) -> str:
        """`send_and_wait` in the running event loop's default executor."""
    def disconnect(self, timeout: float | None = 2.0) -> None:
        """`start_disconnect()`, then waits for its `Disconnected`.
        Raises `RejectedError` (not asked for), `TimeoutError`, `RuntimeError` from the event
        callback, `StoppedError`."""
    async def disconnect_async(self, timeout: float | None = 2.0) -> None:
        """`disconnect` in the running event loop's default executor."""
    def send_command(self, command: str) -> None:
        """Sends an instrument command ("?", "ID?", "MM"...; the carriage return is added).

        Commands to one instrument are written one at a time, each after the previous reply or
        its timeout. Results: `InstrumentResponseReceived`, `InstrumentResponseTimeout`, `InstrumentCommandDropped`, or `Rejected` when
        the instrument is not ready. Raises `ValueError` for an empty command.
        """
    def start_disconnect(self) -> None:
        """Disconnects and stops reconnecting (`Disconnected`, `DisconnectReason.REQUESTED`)."""

@final
class EventIterator:
    """Iterator returned by `BleManager.events()`."""

    def __iter__(self) -> Self: ...
    def __next__(self) -> Event: ...

@final
class BleScan:
    """The scan of a `BleManager` (`BleManager.scan`): what it lists, when, and the devices
    heard. A cheap handle: keep it, or take it again from `BleManager.scan`. Its calls raise
    `StoppedError` once the manager is stopped.
    """

    @property
    def sylvac_only(self) -> bool:
        """Whether the scan lists only Sylvac devices (the 20 Sylvac name prefixes). False at
        start. Set it before or during a scan; the list is filtered again at once:
        `AdvertiserRemoved` for each device listed that no longer passes, `AdvertiserChanged`
        for each device heard in the last minute that now does. Connected instruments are not
        affected.
        """
    @sylvac_only.setter
    def sylvac_only(self, on: bool) -> None: ...
    def start(self) -> None:
        """Lists the devices heard (`AdvertiserChanged` events, `advertisers()`), filtered by
        `sylvac_only`."""
    def start_on(self, central: str) -> None:
        """The dongle `central` scans and its advertisements make the list, instead of the
        dongle the library chooses. It keeps the scan while it is ready. `start()` or
        `stop()` give the choice back to the library. A dongle that is not ready: a
        `LibLog` warning. Raises `ValueError` for a bad address."""
    def stop(self) -> None:
        """Stops listing the devices heard."""
    def stop_on(self, central: str) -> None:
        """When `central` is the scanning dongle, the list stops and the choice goes back to the
        library; otherwise nothing."""
    def clear(self) -> None:
        """Empties the list of devices heard, with an `AdvertiserRemoved` for each; a device
        still around is listed again at its next advertisement."""
    def advertisers(self) -> list[BleAdvertiser]:
        """The devices heard in the last 60 s while scanning."""

@final
class BleManager:
    """The library: dongles, scan, instruments, events.

    Creating it starts the library on its own thread: it finds the dongles (hot-plug on Windows,
    a rescan every second on Linux, or fixed ports), spreads the instruments over them,
    reconnects instruments that drop, and reports everything as events. Calls return at once;
    their results come back as events.

    Use it as a context manager, or call `stop()`; a manager still running when the interpreter
    exits is stopped then.

    Arguments (keyword only):
        ports: ports that always hold a dongle ("COM5", "/dev/ttyS2" for a board UART), opened
            at start and reopened every 5 s after a failure.
        hot_plug: find USB dongles by themselves.
        auto_reassign: the default `BlePeripheral.auto_reassign` of each instrument
            asked for (default False).
        response_timeout: seconds an instrument has to answer a command before
            `InstrumentResponseTimeout`; `None` for the library's default.
        queue_capacity: events kept for `next_event`; beyond, advertiser events are dropped
            first and `Overflow` says how many.
        log_level: the most detailed `LibLog` level sent (`LogLevel.WARNING` by default,
            `LogLevel.NONE` sends none).

    Raises `ValueError` when `hot_plug` is false and `ports` is empty, `StartError` when the
    library could not start.
    """

    def __new__(
        cls,
        *,
        ports: Sequence[str] = ...,
        hot_plug: bool = True,
        auto_reassign: bool = False,
        response_timeout: float | None = None,
        queue_capacity: int = 10000,
        log_level: LogLevel = ...,
    ) -> Self: ...
    def next_event(self, timeout: float | None = None) -> Event | None:
        """The next event, waiting up to `timeout` seconds (`None`: until one comes; 0: do not
        wait). Returns `None` when none came in time.

        Ctrl+C interrupts the wait; other Python threads run meanwhile. While a callback is
        set, events go to it instead. Raises `StoppedError` once the manager is stopped and
        every event was taken, `RuntimeError` when called from the event callback.
        """
    def events(self, timeout: float | None = None) -> EventIterator:
        """An iterator over the events: `for event in manager.events(): ...`.

        It ends once the manager is stopped and every event was taken, or, with a `timeout` in
        seconds, as soon as no event came for that long. Iterating the manager is `events()`.
        """
    def __iter__(self) -> EventIterator: ...
    def events_async(self) -> AsyncIterator[Event]:
        """An asynchronous iterator over the events, for asyncio:
        `async for event in manager.events_async(): ...`.

        It uses the callback, so `next_event` and `set_callback` are not for use meanwhile;
        events still queued come first. It ends when the manager stops; closing it gives the
        events back to the queue.
        """
    def set_callback(self, callback: Callable[[Event], object] | None) -> None:
        """Sends every event to `callback(event)` on the library thread instead of the queue;
        `None` sends them to the queue again.

        Events still queued are given to the callback first. The callback must return quickly
        (a GUI passes the event on to its own thread); calls it makes on the manager are
        carried out after it returns. An exception it raises is printed
        (`sys.unraisablehook`) and the callback stays set.
        """
    def _set_callback(
        self, callback: Callable[[Event], object], on_close: Callable[[], object]
    ) -> None: ...
    def connect(
        self, mac: str, central: str | None = None, timeout: float | None = 30.0
    ) -> BlePeripheral:
        """`start_connect(mac, central)`, then waits up to `timeout` seconds (`None`: until it
        comes) for `ConnectionStep.SUBSCRIBED`; at once when already subscribed. The events
        still go to the queue or callback, the one that settled the wait first. Raises
        `TimeoutError` (the instrument keeps connecting), `RejectedError`, `ReleasedError`,
        `RuntimeError` from the event callback, `ValueError`, `StoppedError`."""
    async def connect_async(
        self, mac: str, central: str | None = None, timeout: float | None = 30.0
    ) -> BlePeripheral:
        """`connect` in the running event loop's default executor."""
    def delete_bond(self, central: str, mac: str) -> None:
        """The dongle `central` deletes its bond with the instrument `mac`; once the dongle
        confirms, `BondedMacsListChanged` (removed). A `Rejected` event with
        `RejectReason.NO_BOND` when it holds none, `UNKNOWN_CENTRAL` when `central` is not a
        ready dongle. Raises `ValueError` for a bad address."""
    def start_disconnect_all(self) -> None:
        """`start_disconnect()` for every instrument, in MAC order."""
    def reset_connections(self, central: str) -> None:
        """Every instrument placed on the dongle `central` is released as by
        `start_disconnect()`, the dongle drops all its links and deletes all its bonds, and its
        `bonded_macs` is emptied. A dongle that is not ready: a `LibLog` warning."""
    def start_connect(self, mac: str, central: str | None = None) -> BlePeripheral:
        """Connects the instrument with this Bluetooth address ("D216182F6CCC",
        "d2:16:18:2f:6c:cc" or "D2-16-...") and keeps it connected until
        `BlePeripheral.start_disconnect()`.

        With no dongle ready yet it waits for the first one. With `central`, on that dongle:
        `Rejected` with `RejectReason.CENTRAL_FULL` when it has no free slot, `UNKNOWN_CENTRAL`
        when it is not a ready dongle. Progress: `PeripheralAdded` (when not in the list yet),
        `CentralToConnectChanged`, `Connecting`, `ConnectionStepChanged` up to
        `ConnectionStep.SUBSCRIBED`; refusal: `Rejected`, then `PeripheralRemoved` when it was
        added. Raises `ValueError` for a bad address.
        """
    def peripheral(self, mac: str) -> BlePeripheral:
        """A handle for an instrument already asked for (e.g. the `instrument` of an event)."""
    @property
    def scan(self) -> BleScan:
        """The scan: its `sylvac_only` filter, `start()` and `stop()`, the `advertisers()`
        heard."""
    def centrals(self) -> list[BleCentral]:
        """The ready dongles."""
    def peripherals(self) -> list[BlePeripheral]:
        """The instruments asked for with `start_connect` and not disconnected
        (`PeripheralAdded` / `PeripheralRemoved`)."""
    def stop(self) -> None:
        """Disconnects every instrument, closes the dongles (about 1.5 s at most) and ends the
        library thread; the callback is not called after it returns.

        The last events stay available to `next_event`. Called from the callback, it only asks
        the thread to stop. Repeating it is harmless.
        """
    def is_finished(self) -> bool:
        """The library thread has ended and no more events will come."""
    def __enter__(self) -> Self: ...
    def __exit__(
        self,
        exc_type: type[BaseException] | None = None,
        exc_value: BaseException | None = None,
        traceback: TracebackType | None = None,
    ) -> None: ...

def _stop_all() -> None: ...
def _sample_events() -> list[Event]: ...
